<footer  style="background-color: black;">
            <!-- Copyright -->
            <div class="container g-padding-y-40--xs" style="width: 90%">
                
                <div class="row">
                    <div class="col-sm-6" align="center" style="padding-bottom: 10px;">
                      <span class="copyright" style="color:#13b1cd; font-weight: 400;">Yash Patel,Sne Patel,Tarang Patel,Vaghesh Patel
                      </span>
                    </div>
                    <div class="col-sm-6">
                        <ul style="text-align: center; padding-left: 0px;" >  
                        <li type="none" style="color: white;">        
                                <a href="index.php" style="color: white; font-weight: 400;">Home</a>
                                |                                 
                                <a href="mission.php" style="color: white; font-weight: 400;">Activities</a>
                                |
                                <a href="contactus.php" style="color: white; font-weight: 400;">Contact Us</a>
                                |
								<a href="login.php" style="color: white; font-weight: 400;">Logout</a>
                                <!--<a href="login.php" style="color: white; font-weight: 400;">Login</a>!-->
                        </li>   
                        </ul>
                    </div>
                </div>
            </div>
        <!-- End Copyright -->
</footer>