<!--
	//session_start();
	//$enroll = 	$_SESSION['enroll'];
//	$nam = 	$_SESSION['name'];
!-->
<link rel="icon" href="images/favicon.ico" type="image/x-icon">
<header class="navbar-fixed-top s-header-v2 js__header-sticky">

            <!-- Navbar -->
            <nav class="s-header-v2__navbar">
                <div class="container g-display-table--lg">
                    <!-- Navbar Row -->
                    <div class="s-header-v2__navbar-row">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="s-header-v2__navbar-col">
                            <button type="button" class="collapsed s-header-v2__toggle" data-toggle="collapse" data-target="#nav-collapse" aria-expanded="false">
                                <span class="s-header-v2__toggle-icon-bar"></span>
                            </button>
                        </div>

                        <div class="s-header-v2__navbar-col s-header-v2__navbar-col-width--180">
                            <!-- Logo -->
                            <div class="s-header-v2__logo">
                                <a href="index.php" class="s-header-v2__logo-link">
                                    <img class="s-header-v2__logo-img s-header-v2__logo-img--default" src="img/clogo.png" height="25px" widht="60px" alt="AnnapurnaLogo">
                                    <img class="s-header-v2__logo-img s-header-v2__logo-img--shrink" src="img/clogo1.png" height="25px" widht="60px" alt="Annapurna Logo">
                                </a>
                            </div>
                            <!-- End Logo -->
                        </div>
                      
                        <div class="s-header-v2__navbar-col s-header-v2__navbar-col--right">
                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse s-header-v2__navbar-collapse" id="nav-collapse">
                                <ul class="s-header-v2__nav">
                                    <!-- Home -->
                                    <!-- <li class="dropdown s-header-v2__nav-item s-header-v2__dropdown-on-hover">
                                        <a href="index.html" class="dropdown-toggle s-header-v2__nav-link -is-active" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Home <span class="g-font-size-10--xs g-margin-l-5--xs ti-angle-down"></span></a>
                                    </li> -->
                                     <li class="s-header-v2__nav-item"><a href="GuestIndex.php" class="s-header-v2__nav-link">Home</a></li>
                                    <!-- End Home -->
                                    <li class="s-header-v2__nav-item"><a href="GuestMission.php" class="s-header-v2__nav-link">Activities</a></li>
                                    <li class="s-header-v2__nav-item"><a href="GuestUpcoming.php" class="s-header-v2__nav-link">Upcoming Events</a></li>
                                    <!-- <li class="s-header-v2__nav-item"><a href="destributor.php" class="s-header-v2__nav-link">Contact Us</a></li> -->
                                    
                                    <!-- <li class="s-header-v2__nav-item"><a href="enquiry.php" class="s-header-v2__nav-link">Enquiry</a></li>
                                    <li class="s-header-v2__nav-item"><a href="career.php" class="s-header-v2__nav-link s-header-v2__nav-link--dark">Career</a></li> -->
                                    <!-- <li class="s-header-v2__nav-item"><a href="about.php" class="s-header-v2__nav-link">About Us</a></li> -->
                                    <!-- <li class="dropdown s-header-v2__nav-item s-header-v2__dropdown-on-hover">
                                        <a href="about.php" class="dropdown-toggle s-header-v2__nav-link" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">About <span class="g-font-size-10--xs g-margin-l-5--xs ti-angle-down"></span></a>
                                        <ul class="dropdown-menu s-header-v2__dropdown-menu">
                                            <li><a href="team.php" class="s-header-v2__dropdown-menu-link">Team</a></li>
                                            <li><a href="about.php" class="s-header-v2__dropdown-menu-link">About</a></li>
                                             <li><a href="abouthing.php" class="s-header-v2__dropdown-menu-link">About Hing</a></li>
                                             <li><a href="infra.php" class="s-header-v2__dropdown-menu-link">Infrastructure</a></li>
                                            <li><a href="companyprofile.php" class="s-header-v2__dropdown-menu-link">Comapny Profile</a></li>
                                        </ul>
                                    </li>-->		
									
                                    <li class="s-header-v2__nav-item"><a href="GuestContactus.php" class="s-header-v2__nav-link">Contact Us</a></li>
                                            
                                        
                                   <li class="s-header-v2__nav-item"><a href="login.php" class="s-header-v2__nav-link">Logout Guest</a></li>
                                 </ul>
                            </div>
                            <!-- End Nav Menu -->
                        </div>
                    </div>
                    <!-- End Navbar Row -->
                </div>
            </nav>
            <!-- End Navbar -->
        </header>