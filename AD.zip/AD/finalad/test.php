<div class="row">

                <!-- blog grid -->
                <div class="col-lg-4 col-md-6">
                    <div class="card border-0 med-blog">
                        <div class="card-header p-0">
                            <a href="single.html">
								<img class="card-img-bottom" src="images/blood.jpg" alt="image">
							</a>
                        </div>
                        <div class="card-body border border-top-0 pb-5">
                            <div class="mb-3">
                                <h5 class="blog-title card-title font-weight-bold m-0">
                                    <a href="single.html">Blood Donate Camp</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
										Feb 28, 2019</span><br/>
                                    <span>
                                        Timings: 09:30am to 03:00pm</span>
                                </div>
                            </div>
                            <p class="mb-4">All students are encouraged to contribute and "Get Blessed by the Unknowns who are getting your help".</p>  
                        </div>
                    </div>
                </div>
                <!-- //blog grid -->

                <!-- blog grid -->
                <div class="col-lg-4 col-md-6">
                    <div class="card border-0 med-blog">
                        <div class="card-body border border-bottom-0 pb-5">
                            <div class="mb-3">
                                <h5 class="blog-title card-title font-weight-bold m-0">
                                    <a href="single.html">Dance</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
										Last Day for registration: 03-03-2019</span>
                                </div>
                            </div>
                            <p class="mb-4">Here, Three types of Dance Arranges 1)Solo<br/> 2)Group<br/> 3)Duet</p>
                            
                        </div>
                        <div class="card-header p-0">
                            <a href="single.html">
								<img class="card-img-bottom" src="images/dance.jpg" alt="image">
							</a>
                        </div>
                    </div>
                </div>
                <!-- //blog grid -->
                <!-- blog grid -->
                <div class="col-lg-4 col-md-6">
                    <div class="card border-0 med-blog">
                        <div class="card-header p-0">
                            <a href="single.html">
								<img class="card-img-bottom" src="images/g2.jpg" alt="image">
							</a>
                        </div>
                        <div class="card-body border border-top-0 pb-5">
                            <div class="mb-3">
                                <h5 class="blog-title card-title font-weight-bold m-0">
                                    <a href="single.html">Fashion Show</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
										Last Day for registration: 03-03-2019</span>
                                </div>
                            </div>
                            <p class="mb-4">Onces Fashion show theme will decided after Institute will give further information.
                            </p>
                            
                        </div>
                    </div>
                </div>
                <!-- //blog grid -->
            </div>


            <div class="row mt-5">
                <!-- blog grid -->
                <div class="col-lg-4 col-md-6">
                    <div class="card border-0 med-blog">
                        <div class="card-header p-0">
                            <a href="single.html">
								<img class="card-img-bottom" src="images/sing.jpg" alt="image">
							</a>
                        </div>
                        <div class="card-body border border-top-0 pb-5">
                            <div class="mb-3">
                                <h5 class="blog-title card-title font-weight-bold m-0">
                                    <a href="single.html">Singing</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
										Last Day for registration: 03-03-2019</span>
                                </div>
                            </div>
                            <p class="mb-4">Here, Two type of singing arranges<br/> 1)Solo <br> 2)Group</p>
                            
                        </div>
                    </div>
                </div>
                <!-- //blog grid -->
                <!-- blog grid -->
                <div class="col-lg-4 col-md-6 mt-md-0 mt-5">
                    <div class="card border-0 med-blog">
                        <div class="card-body border border-bottom-0 pb-5">
                            <div class="mb-3">
                                <h5 class="blog-title card-title font-weight-bold m-0">
                                    <a href="single.html">Drama</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
										Last Day for registration: 03-03-2019</span>
                                </div>
                            </div>
                            <p class="mb-4">Drama is the best event to give big message to people.</p>
                            <div class="price-button mt-md-3 mt-2">
                               
                            </div>
                        </div>
                        <div class="card-header p-0">
                            <a href="single.html">
								<img class="card-img-bottom" src="images/drama.jpg" alt="image">
							</a>
                        </div>
                    </div>
                </div>
                <!-- //blog grid -->
                <!-- blog grid -->
                <div class="col-lg-4 col-md-6 mt-lg-0 mt-5">
                    <div class="card border-0 med-blog">
                        <div class="card-header p-0">
                            <a href="single.html">
								<img class="card-img-bottom" src="images/standup.jpg" alt="image">
							</a>
                        </div>
                        <div class="card-body border border-top-0 pb-5">
                            <div class="mb-3">
                                <h5 class="blog-title card-title font-weight-bold m-0">
                                    <a href="single.html">Stand up comedy</a>
                                </h5>
                                <div class="blog_w3icon">
                                    <span>
										Last Day for registration: 03-03-2019</span>
                                </div>
                            </div>
                            <p class="mb-4">Comedy comes, it bring with smile it is nothing but key that fits the lock of everybody's heart.</p>
                            
                        </div>
                    </div>
                </div>
                <!-- //blog grid -->
            </div>
        </div>
