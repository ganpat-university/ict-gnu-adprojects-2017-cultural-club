-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2019 at 06:39 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_createevent`
--

CREATE TABLE `admin_createevent` (
  `event_id` int(11) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `event_desc` varchar(800) NOT NULL,
  `lastdate_reg` date NOT NULL,
  `event_image` varchar(100) NOT NULL,
  `Category` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_createevent`
--

INSERT INTO `admin_createevent` (`event_id`, `event_name`, `start_date`, `end_date`, `start_time`, `end_time`, `event_desc`, `lastdate_reg`, `event_image`, `Category`) VALUES
(5, 'Drama', '2019-04-30', '2019-04-30', '16:00:00', '18:00:00', 'This Event will start at time of Cultural Festival', '2019-04-16', 'drama.jpg', 'on stage event'),
(7, 'Dance(solo)', '2019-04-30', '2019-04-30', '14:15:00', '16:00:00', 'A dance troupe or dance company is a group of dancers and associated personnel who work together to perform dances as a spectacle or entertainment. There are many different types of dance companies, often working in different styles of dance.', '2019-04-22', 'dance.jpg', 'on stage event'),
(8, 'Dance(Group)', '2019-04-30', '2019-04-30', '14:00:00', '18:00:00', 'A dance troupe or dance company is a group of dancers and associated personnel who work together to perform dances as a spectacle or entertainment. There are many different types of dance companies, often working in different styles of dance.\r\n', '2019-04-23', 'dance.jpg', 'on stage event'),
(9, 'Singing(solo)', '2019-04-30', '2019-04-30', '15:00:00', '18:00:00', 'Singing', '2019-04-23', 'sing.jpg', 'on stage event'),
(10, 'Singing(group)', '2019-04-30', '2019-04-30', '15:00:00', '19:00:00', 'Singing in group', '2019-04-23', 'sing.jpg', 'on stage event'),
(11, 'Blood Donate', '2019-04-30', '2019-04-30', '15:00:00', '06:00:00', 'Blood Donate for every students as well as for faculty.', '0000-00-00', 'blood.jpg', 'on campus event');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `Enrollment` bigint(14) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `Semester` varchar(20) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Mobile` bigint(13) NOT NULL,
  `StageEvents` varchar(30) NOT NULL,
  `CampusEvents` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`Enrollment`, `Name`, `Branch`, `Semester`, `Email`, `Mobile`, `StageEvents`, `CampusEvents`) VALUES
(17162101029, 'SNE', 'cba', '4', 'snepatel2000@gmail.com', 9664994949, 'Dance(Solo)', 'Group Dance'),
(17162101029, 'SNE', 'cba', '4', 'snepatel2000@gmail.com', 9664994949, 'Singing(Solo)', 'Group Drama'),
(17162101029, 'SNE', 'cba', '4', 'snepatel2000@gmail.com', 9664994949, 'Fashion Show', 'None'),
(17162101032, 'yash', 'cba', '4', 'yash.cba1732@ict.gnu.ac.in', 9664994949, 'Stand Up Comedy', 'Group Dance'),
(17162101032, 'yash', 'cba', '4', 'yash.cba1732@ict.gnu.ac.in', 9664994949, 'Drama', 'Group Singing'),
(17162101032, 'yash', 'cba', '4', 'yash.cba1732@ict.gnu.ac.in', 9664994949, 'Dance(Duet)', 'Group Singing'),
(17162101032, 'yash', 'cba', '4', 'yash.cba1732@ict.gnu.ac.in', 9664994949, 'Dance(Duet)', 'Group Drama'),
(17162101021, 'dhrumil', 'cba', '4', 'dpanchal0926@gmail.com', 9537460720, 'Dance(Solo)', 'Group Dance'),
(17162101021, 'dhrumil', 'cba', '4', 'dpanchal0926@gmail.com', 9537460720, 'Stand Up Comedy', 'Group Drama'),
(17162101021, 'dhrumil', 'cba', '4', 'dpanchal0926@gmail.com', 9537460720, 'Drama', 'Group Drama'),
(17162101021, 'dhrumil', 'cba', '4', 'dpanchal0926@gmail.com', 9537460720, 'Fashion Show', 'Group Singing');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `MiddleName` varchar(25) NOT NULL,
  `LastName` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Enrollment` bigint(12) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Mobile` bigint(12) NOT NULL,
  `BirthDate` date DEFAULT NULL,
  `Semester` varchar(20) NOT NULL,
  `Branch` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `FirstName`, `MiddleName`, `LastName`, `Email`, `Enrollment`, `Password`, `Mobile`, `BirthDate`, `Semester`, `Branch`) VALUES
(4, 'SNE', 'MANISHKUMAR', 'PATEL', 'snepatel2000@gmail.com', 17162101029, 'sne123', 9757774773, '2015-06-17', '4', 'cba'),
(2, 'Harikrushn', 'Mohanbhai', 'Tanchak', 'tanchakharikrushn@gmail.com', 150170116055, 'hari143', 9586564451, '1998-02-09', '8', 'cba'),
(3, 'dhrumil', 'pRAVINBHAI', 'panchal', 'dpanchal0926@gmail.com', 17162101021, 'DHRUMIL', 9537460720, '2000-02-02', '4', 'cba');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_createevent`
--
ALTER TABLE `admin_createevent`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_createevent`
--
ALTER TABLE `admin_createevent`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
