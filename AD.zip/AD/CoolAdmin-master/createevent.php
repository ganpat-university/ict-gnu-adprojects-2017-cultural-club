<?php
include 'config.php';
$category=$_POST['category'];
$eventname=$_POST['eventname'];
$start_date=$_POST['Starting-date'];
$end_date=$_POST['Ending-date'];
$start_time=$_POST['startingtime'];
$end_time=$_POST['endingtime'];
$description=$_POST['description'];
$lastdate_reg=$_POST['last-date'];
$eventimage=$_POST['fileuploaded'];

$query="INSERT INTO admin_createevent(event_name,start_date,end_date,start_time,end_time,event_desc,lastdate_reg,event_image, Category) VALUES ('$eventname','$start_date','$end_date','$start_time','$end_time','$description','$lastdate_reg','$eventimage','$category')";
			
	if($res=mysqli_query($conn,$query))
	{
		echo('<script>window.alert("Your Event Sucessfully Created");
       window.location="show_event.php";
       </script>');
	}
	else
	{
		echo('<script>window.alert("Sorry, Try After Some time");
       window.location="create_event.php";
       </script>');
	}

//echo $eventname;
//echo $start_date;
//echo $end_date;
//echo $start_time;
//echo $end_time;
//echo $description;
//echo $lastdate_reg;
//echo $eventimage;
?>