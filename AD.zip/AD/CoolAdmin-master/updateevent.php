<?php
include 'config.php';
$id=$_POST['id'];
$category=$_POST['category'];
$eventname=$_POST['eventname'];
$Startingdate=$_POST['Starting-date'];
$Endingdate=$_POST['Ending-date'];
$startingtime=$_POST['startingtime'];
$endingtime=$_POST['endingtime'];
$description=$_POST['description'];
$lastdate=$_POST['last-date'];
//$eventimage=$_POST['fileuploaded'];


$query="UPDATE admin_createevent SET event_name='$eventname',start_date='$Startingdate', end_date='$Endingdate',start_time='$startingtime',end_time='$endingtime',event_desc='$description',lastdate_reg='$lastdate', Category='$category' WHERE event_id='$id'";
			
	if($res=mysqli_query($conn,$query))
	{
		echo('<script>window.alert("Your Event Sucessfully Updated");
       window.location="show_event.php";
       </script>');
	}
	else
	{
		echo('<script>window.alert("Sorry, Try After Some time");
       window.location="create_event.php";
       </script>');
	}







?>