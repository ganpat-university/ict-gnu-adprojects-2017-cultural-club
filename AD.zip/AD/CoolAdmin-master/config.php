<?php
$conn=mysqli_connect("localhost", "root", "", "CC") or die("connection not establish");
?>