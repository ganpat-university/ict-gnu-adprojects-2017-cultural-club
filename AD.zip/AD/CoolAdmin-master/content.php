<?php
include 'config.php';

$data=$_GET['data'];
$query="SELECT * from events where Name='$data'";
$res=mysqli_query($conn,$query); 
// if($row=mysqli_fetch_array($res))
// {
// 	$list=$row['StageEvents'];
// 	echo true;	
	
// }
// else
// {
// 	echo false;
// }
$id=1;
$output="";
           $output .= '
           <thead>
           <tr>  
                <td width="10%" style="text-align:center; color:white;"><label>No.</label></td>  
                <td width="50%" style="text-align:center; color:white;"><label>Stage Events</label></td> 
                <td width="50%" style="text-align:center; color:white;"><label>Campus Events</label></td>  
                  
            </tr> 
            </thead>
            ';
while($row=mysqli_fetch_array($res))
{

            $output .= '
            <tbody>
            <tr>  
                <td width="10%" style="text-align:center;">'.$id++.'</td>
                <td width="50%" style="text-align:center;">'.$row["StageEvents"].'</td>  
                <td width="50%" style="text-align:center;">'.$row["CampusEvents"].'</td> 
            </tr>  
            </tbody>
            
                ';    
} 
      echo $output;
?>