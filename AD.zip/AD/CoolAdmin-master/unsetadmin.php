<?php
session_start();
unset($_SESSION['admin']);
header('Location:../finalad/adminlogin.php');
?>